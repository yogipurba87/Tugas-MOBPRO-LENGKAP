package org.d3rpla4403.galerihewan

data class Hewan(
    val nama: String,
    val namaLatin: String,
    val imageResId: Int
)